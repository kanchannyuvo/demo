package com.example.jpa.model;

/**
 * Created by rajeevkumarsingh on 29/11/17.
 */
public enum Gender {
    MALE,
    FEMALE
}
