package com.unimoni;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration extends BaseClass
{
	public static void main(String[] args) throws InterruptedException {


		WebDriver driver = setUpDriver();

		driver.manage().window().maximize();
		driver.get("http://demo.automationtesting.in/Register.html");

		driver.findElement(By.xpath("//input[@ng-model='FirstName']")).sendKeys("Kanchan ");
		driver.findElement(By.xpath("//input[@ng-model='LastName']")).sendKeys(" Durgapal");
		driver.findElement(By.xpath("//textarea[@ng-model='Adress']")).sendKeys("Nerul Navi Mumbai");
		driver.findElement(By.xpath("//input[@ng-model='EmailAdress']")).sendKeys("Test@test.com");
		driver.findElement(By.xpath("//input[@ng-model='Phone']")).sendKeys("8108294859");
		driver.findElement(By.xpath("//input[@ng-model='radiovalue']")).click();
		driver.findElement(By.id("checkbox1")).click();
		driver.findElement(By.id("checkbox2")).click();
		
		Thread.sleep(10000);

		Select selectDrop = new Select(driver.findElement(By.xpath("//select[@ng-model='Skill']")));

		selectDrop.selectByValue("Java");


		Select selectCountryDrop = new Select(driver.findElement(By.id("countries")));

		selectCountryDrop.selectByValue("India");

		Select selectCountryDrop2 = new Select(driver.findElement(By.id("country")));

		selectCountryDrop2.selectByValue("India");


		Select selectYear = new Select(driver.findElement(By.xpath("//select[@ng-model=\"yearbox\"]")));

		selectYear.selectByValue("1987");

		Select selectMonth = new Select(driver.findElement(By.xpath("//select[@ng-model=\"monthbox\"]")));

		selectMonth.selectByValue("June");



		Select selectDays = new Select(driver.findElement(By.xpath("//select[@ng-model=\"daybox\"]")));

		selectDays.selectByValue("25");


		driver.findElement(By.xpath("//input[@ng-model='Password']")).sendKeys("Password@1");
		
		driver.findElement(By.xpath("//input[@ng-model='CPassword']")).sendKeys("Password@1");
		
		
		driver.findElement(By.name("signup")).click();
		
		
	

	}

}
